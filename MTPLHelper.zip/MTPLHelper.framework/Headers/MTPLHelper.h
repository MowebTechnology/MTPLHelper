//
//  MTPLHelper.h
//  MTPLHelper
//
//  Created by Ankit Patel on 04/02/20.
//  Copyright © 2020 Moweb. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MTPLHelper.
FOUNDATION_EXPORT double MTPLHelperVersionNumber;

//! Project version string for MTPLHelper.
FOUNDATION_EXPORT const unsigned char MTPLHelperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTPLHelper/PublicHeader.h>


