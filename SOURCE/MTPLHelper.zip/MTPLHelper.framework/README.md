***********************************************


BUILDING AN UPDATED FRAMEWORK


***********************************************

1. CHOOSE SCHEME :- MTPLHelper-Universal
2. CHOOSE DEVICE > Generic iOS Device
3. Archive Product
4. Wait......
5. MTPLHelper.framework selected folder will automatically open after 3-5 seconds
6. Drag that framework folder to any project to test
7. Tested framework can be uploaded as .zip file
